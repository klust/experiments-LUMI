module timer

   contains

   ! Elapsed time in seconds
   double precision function gettime()
   integer(selected_int_kind(9)),parameter :: i64=selected_int_kind(18)
   integer(kind=i64) c,r

   call system_clock(count=c,count_rate=r)
   gettime = dble(c)/dble(r)

   end function gettime

end module timer
