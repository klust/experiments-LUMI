// Code from Cray Programming Models Examples
//
// C

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char **argv){
  const long long nmax_x=4000,nmax_y=4000;
  const int max_cycles = 1000;
  double c1_r,c1_i,c2_r,c2_i;
  double z_r,z_i,z_rs,z_is,area,c_r,c_i;
  long long count;
  int i,j,cycle;

  printf("approximation to Mandelbrot area by serial program\n");

  c1_r = -2.25; c1_i = -1.5;
  c2_r =  0.75; c2_i =  1.5;
  count=0;

  for(i=0;i<=nmax_x;i++){
    c_r=c1_r + (c2_r-c1_r)*((double)i/nmax_x);
    for(j=0;j<=nmax_x;j++){
      c_i=c1_i + (c2_i-c1_i)*((double)j/nmax_y);

      // First iteration starts with z=0
      z_r = c_r;
      z_i = c_i;
      z_rs = z_r*z_r;
      z_is = z_i*z_i;

      for(cycle=0;cycle<=max_cycles;cycle++){
	if (z_rs+z_is > 4.0) break;
          z_rs = z_r*z_r;
          z_is = z_i*z_i;
          z_i = 2*z_r*z_i + c_i;
          z_r = (z_rs - z_is) + c_r;
       }
      if (cycle>max_cycles){ count++ ;};
    }
  }

  area=(double)count*((c2_r-c1_r)/nmax_x)*((c2_i-c1_i)/nmax_y);


  printf("   area = %21.18f\n\n",area);

}


  
