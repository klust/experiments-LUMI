// Code from Cray Programming Models Examples
//
// C pthreads 2d decomposition

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "params_mandel.h" // For nmax_x,nmax_y,max_cycles
#include "timer.h"

#define TRUE 1
#define FALSE 0
static const int circumference_optimize=TRUE;

static int nthreads;
static long long count;
static pthread_mutex_t count_mutex;
static double c1_r,c1_i,c2_r,c2_i;

// Get a 2d decomposition of n  Example 13 -> 3,4
// Find most square factors
static int decompose_2d(int n,int *nx, int *ny)
{
  int f;
  f=(int)sqrt(n);
  while(n%f!=0){f--;} // will end up at 1 if no other factors
  *nx = n/f;
  *ny = n /(*nx);
  return (*nx * *ny);
}

// Counts number of points in the set
long long inside_count(int istart,int iend,int jstart,int jend,
                       int circ_opt){
  long long mycount;
  double z_r,z_i,z_rs,z_is,area,c_r,c_i;
  int i,j,cycle;
  int is,ie,js,je;

  is = istart; ie = iend;
  js = jstart; je = jend;

  mycount=0;

  if (circ_opt){
    // Do the edges
    mycount+=inside_count(istart,iend,jstart,jstart,FALSE);
    mycount+=inside_count(istart,iend,jend,jend,FALSE);
    mycount+=inside_count(istart,istart,jstart+1,jend-1,FALSE);
    mycount+=inside_count(iend,iend,jstart+1,jend-1,FALSE);

    /* Not accurate (I think we loose connectedness with sampling space)
    if (mycount==0){ 
      return mycount ;
     }
    */
    // Check if the whole edge was inside, if so then interior should be
    if (mycount==2*( (iend-istart+1) + (jend-jstart-1 ) )){
      return (long long)(iend-istart+1)*(jend-jstart+1) ;
    }

    // at this point we have the count for the edge
    is++,ie--;js++;je--;

   }

  for(i=is;i<=ie;i++){
    c_r=c1_r + (c2_r-c1_r)*((double)i/nmax_x);
    for(j=js;j<=je;j++){
      c_i=c1_i + (c2_i-c1_i)*((double)j/nmax_y);

      // First iteration starts with z=0
      z_r = c_r;
      z_i = c_i;
      z_rs = z_r*z_r;
      z_is = z_i*z_i;

      for(cycle=0;cycle<=max_cycles;cycle++){
	if (z_rs+z_is > 4.0) break;
          z_rs = z_r*z_r;
          z_is = z_i*z_i;
          z_i = 2*z_r*z_i + c_i;
          z_r = (z_rs - z_is) + c_r;
       }
      if (cycle>max_cycles){ mycount++ ;};
    }
  }

  return mycount;

}

void *worker(void * data){
  int istart,iend,jstart,jend,cycle,tid;
  long long mycount;
  int ntx,nty,ntxy,my_tx,my_ty ;

  tid=*((int *) data);

  ntxy = decompose_2d(nthreads,&ntx,&nty);
  if (tid==0) {printf("decomposed %d to %d (%d,%d)\n",nthreads,ntxy,ntx,nty);}
                      
  if (tid > ntxy -1 ) { return NULL; }

  my_tx = tid % ntx ;
  my_ty = tid / ntx ;

  // Deompose X (real) and Y (imag) to tasks
  istart = my_tx *(nmax_x/ntx);
  iend  = istart + (nmax_x/ntx) - 1;
  if (my_tx==ntx-1) { iend = nmax_x ;}

  jstart = my_ty *(nmax_y/nty);
  jend  = jstart + (nmax_y/nty) - 1;
  if (my_ty==nty-1) { jend = nmax_y ;}

  mycount = inside_count(istart,iend,jstart,jend,circumference_optimize) ;

  // Mutex use came from illustrative pi example, can we get from worker
  // return value?
  pthread_mutex_lock(&count_mutex);
  count+=mycount;
  pthread_mutex_unlock(&count_mutex);

  printf("tid=%d (%d,%d) istart=%d iend=%d jstart=%d jend=%d mycount=%lld\n",
	 tid,my_tx,my_ty,istart,iend,jstart,jend,mycount);

  return NULL;
}

int main(int argc, char **argv){
  int tid,rc,*i;
  pthread_t *threads;
  char *oenv;
  gettime_t t1,t2;
  double area; 

  c1_r = -2.25; c1_i = -1.5;
  c2_r =  0.75; c2_i =  1.5;

  oenv = getenv("OMP_NUM_THREADS");
  if (oenv==NULL){
    nthreads=1;
  } else {
    nthreads=atoi(oenv);
  }
  printf("approximationgr to Mandelbrot area by pthreads program using %d threads\n",nthreads);

  if (nthreads>1){
    threads = (pthread_t *)malloc((size_t)nthreads*sizeof(pthread_t));
    pthread_mutex_init(&count_mutex,NULL);
  }

  t1=gettime();

  for(tid=1;tid<nthreads;tid++){
    i = (int *)malloc(sizeof(*i));
    *i = tid;
    rc = pthread_create(&threads[tid], NULL, worker, (void *)i);
    if (rc){
      printf("ERROR; return code from pthread_create() is %d\n", rc);
      exit(22);
    }
  }
  i = (int *)malloc(sizeof(*i));
  *i = 0;
  worker((void *)i);
  for(tid=1;tid<nthreads;tid++){
    void *status;
    rc = pthread_join(threads[tid], &status);
   }


  area=(double)count*((c2_r-c1_r)/nmax_x)*((c2_i-c1_i)/nmax_y);
  t2=gettime();

  //  printf("   area = %21.18f\n\n",area);
  printf("   area = %21.18f (%lld/%lld)\n\n",area,count,nmax_x*nmax_y);

  printf("Elapsed time was %.2fs\n",t2-t1);

  return EXIT_SUCCESS;
  
}


  
