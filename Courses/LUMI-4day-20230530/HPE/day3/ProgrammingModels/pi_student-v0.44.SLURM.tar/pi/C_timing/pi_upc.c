// Code from Cray Programming Models Examples
//
// UPC

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <upc.h>
#include "params.h" // For nmax
#include "timer.h"

int main(int argc, char **argv){
  const double pi=3.14159265358979323846264338327950288;
  double diff,mypi,x,y;
  static shared long long count[THREADS]; // Shared among threads
  int i,j;
  gettime_t t1,t2;

  if (MYTHREAD==0) printf("PI approximation by UPC program using %d threads\n",THREADS);

  t1=gettime();

  count[MYTHREAD] = 0;
  upc_forall(i=0;i<nmax;i++;i){
    x = (i+0.5)/nmax;
    for(j=0;j<nmax;j++){
      y = (j+0.5)/nmax;
      if ( x*x + y*y < 1.0 ) count[MYTHREAD]++;
    }      
  }
  upc_barrier;

  t2=gettime();

  if (!MYTHREAD){
    for(i=1;i<THREADS;i++)count[MYTHREAD]+=count[i];
    mypi=4*(double)count[MYTHREAD]/nmax/nmax;
    printf("   PI = %20.18f\n myPI = %20.18f\n diff = %10.8f%%\n",
           pi,mypi,fabs(mypi-pi)/pi*100);
    printf("Elapsed time was %.2fs\n",t2-t1);
   }

  return EXIT_SUCCESS;

}


  
