! Code from Cray Programming Models Examples
!
! Fortran mandel serial
! Probably need 16k grid and cycles to get 1E-6 error
  program mandelarea
  use image_pgm
  implicit none
  integer(selected_int_kind(9)),parameter :: i64=selected_int_kind(18)
  integer, parameter :: nmax_x=4000, nmax_y=4000
  integer, parameter :: max_cycles=1000
  double precision c1_r,c1_i,c2_r,c2_i
  double precision diff,mypi,z_r,z_i,z_rs,z_is,area,c_r,c_i,x,y
  integer i,j,cycle
  integer(kind=i64) count
!  integer pic(0:nmax_x,0:nmax_y)

  print '(a)',"approximation to Mandelbrot area by serial program"

  c1_r = -2.25d0; c1_i = -1.5d0
  c2_r =  0.75d0; c2_i =  1.5d0
  count=0
  do i=0,nmax_x
   c_r=c1_r + (c2_r-c1_r)*(dble(i)/nmax_x)
   do j=0,nmax_y
    c_i=c1_i + (c2_i-c1_i)*(dble(j)/nmax_y)

! First iteration starts with z=0
    z_r = c_r
    z_i = c_i
    z_rs = z_r**2
    z_is = z_i**2

    do cycle=0,max_cycles
      if (z_rs+z_is > 4d0) exit
        z_rs = z_r**2
        z_is = z_i**2
        z_i = 2*z_r*z_i + c_i
        z_r = (z_rs - z_is) + c_r
     end do
      if (cycle>max_cycles) then
         count=count+1
!         pic(i,j)=0
       else
!        pic(i,j)=255
       end if
    end do
  end do

!  print *,'Image range',minval(pic),maxval(pic)

!  call save_image("mand.pgm",pic,nmax_x+1,nmax_y+1,format="binary")
!  call save_image("mand.pgm",pic,nmax_x+1,nmax_y+1)
  
  area=dble(count)*((c2_r-c1_r)/nmax_x)*((c2_i-c1_i)/nmax_y)

  print "('   area = ',f21.18)",area

  end

  
  
