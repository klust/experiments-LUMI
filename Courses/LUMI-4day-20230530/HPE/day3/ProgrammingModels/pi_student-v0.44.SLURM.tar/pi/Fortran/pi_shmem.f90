! Code from Cray Programming Models Examples
!
! Fortran SHMEM

  program getpi
  implicit none
  include 'mpp/shmem.fh'
  integer(selected_int_kind(9)),parameter :: i64=selected_int_kind(18)
  double precision, parameter :: pi=3.14159265358979323846264338327950288D0
  integer, parameter :: nmax=140000
  double precision diff,mypi,x,y
  integer i,j,istart,iend,ier,mype,npes
  ! Note that count is saved by default so is symmetric in Cray implementation
  integer(kind=i64) count,mycount    

  call start_pes(0)
  mype = shmem_my_pe()
  npes = shmem_n_pes()

  istart = mype * nmax/npes 
  iend = (mype+1) * nmax/npes - 1

  if (mype == npes-1) iend = nmax - 1 ! for non divisors

  if (mype==0) print '(a,i0,a)',&
 &              "PI approximation by SHMEM program using ",&
 &              npes," PEs"


  mycount=0

  call shmem_barrier_all

  do i=istart,iend
   x=(i+0.5D0)/nmax
   do j=0,nmax-1
    y=(j+0.5D0)/nmax
    if (x*x+y*y<1d0) mycount=mycount+1
    end do
  end do

  call shmem_int8_add(count,mycount,0)
  call shmem_barrier_all
  call shmem_finalize

  mypi=4*dble(count)/nmax/nmax

  if (mype==0) then
    print "('   PI = ',f20.18/' myPI = ',f20.18/' diff = ',f10.8,'%')",&
&       pi,mypi,abs(mypi-pi)/pi*100
    end if

 
  end

  
  
