! Code from Cray Programming Models Examples
!
! Fortran OpenACC

  program getpi
  use params     ! For nmax
  use timer
  implicit none
  integer(selected_int_kind(9)),parameter :: i64=selected_int_kind(18)
  double precision, parameter :: pi=3.14159265358979323846264338327950288D0
  double precision diff,mypi,x,y
  integer i,j
  double precision t1,t2
  integer(kind=i64) count

  print '(a)',"PI approximation by OpenACC program"

  t1=gettime()

  count=0
!$acc parallel loop reduction(+:count)
  do i=0,nmax-1
   x=(i+0.5D0)/nmax
   do j=0,nmax-1
    y=(j+0.5D0)/nmax
    if (x*x+y*y<1d0) count=count+1
    end do
  end do
!$acc end parallel loop

  mypi=4*dble(count)/nmax/nmax

  t1=gettime()

  print "('   PI = ',f20.18/' myPI = ',f20.18/' diff = ',f10.8,'%')",&
&       pi,mypi,abs(mypi-pi)/pi*100
  print "('Elapsed time was ',f0.2,'s')",t2-t1

  end

  
  
