! Provide grid size for all examples in this directory
module params
  integer, parameter :: nmax=140000
end module params
