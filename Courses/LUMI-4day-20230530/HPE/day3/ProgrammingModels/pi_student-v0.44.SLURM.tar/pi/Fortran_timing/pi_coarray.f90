! Code from Cray Programming Models Examples
!
! Fortran using parallel features

  program getpi
  use params     ! For nmax
  use timer
  implicit none
  integer(selected_int_kind(9)),parameter :: i64=selected_int_kind(18)
  double precision, parameter :: pi=3.14159265358979323846264338327950288D0
  double precision diff,mypi,x,y
  integer i,j,istart,iend
  double precision t1,t2
  integer(kind=i64) mycount
  integer(kind=i64) :: count[*]=0

  istart = (this_image()-1) * nmax/num_images()
  iend = this_image() * nmax/num_images() - 1

  if (this_image()==num_images()) iend = nmax -1 ! for non divisors

  if (this_image()==1) print '(a,i0,a)',&
 &                     "PI approximation by coarray program using ",&
 &                     num_images()," images"

  t1=gettime()
  mycount=0

  do i=istart,iend
   x=(i+0.5D0)/nmax
   do j=0,nmax-1
    y=(j+0.5D0)/nmax
    if (x*x+y*y<1d0) mycount=mycount+1
    end do
  end do

  critical
  count[1] = count[1] + mycount
  end critical

  sync all

  mypi=4*dble(count)/nmax/nmax

  t2=gettime()

  if (this_image()==1) then
    print "('  PI = ',f20.18/' myPI = ',f20.18/' diff = ',f10.8,'%')",&
&       pi,mypi,abs(mypi-pi)/pi*100
    print "('Elapsed time was ',f0.2,'s')",t2-t1
   end if

  end

  
  
