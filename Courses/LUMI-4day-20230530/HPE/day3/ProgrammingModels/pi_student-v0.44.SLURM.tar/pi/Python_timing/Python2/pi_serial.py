#!/usr/bin/env python
#
# Code from Cray Programming Models Examples
#
# Python2 with timing

import time

t1=time.time()

nmax=140000
nmax=14000
pi=3.14159265358979323846264338327950288

print "PI approximation by serial program"

count = 0

for i in range(nmax):
  x = (i+0.5)/nmax
  for j in range(nmax):
    y = (j+0.5)/nmax
    if ( x*x + y*y < 1.0 ):
      count+=1
      
mypi=4.0*count/nmax/nmax

t2=time.time()

print "   PI = %20.18f\n myPI = %20.18f\n diff = %10.8f%%"  %(pi,mypi,abs(mypi-pi)/pi*100)

print "Elapsed time was %.2fs" %(t2-t1)

  
